//: Playground - noun: a place where people can play

import UIKit


//Serialization com dicionários sem array
let str = "{\"names\": \"Bob\", \"city\": \"SP\", \"age\": \"18\"}"
let data = str.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)!

do {
    let json = try NSJSONSerialization.JSONObjectWithData(data, options: []) as! [String: AnyObject]
    if let x = json["city"] as? String {
        print(x)
    }
    if let x = json["names"] as? String {
        print(x)
    }
} catch let error as NSError {
    print("Failed to load: \(error.localizedDescription)")
}


//Serialization com dicionário names com Array

let str2 = "{\"names\": [\"Bob\", \"Tim\", \"Tina\"]}"
let data2 = str2.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: false)!

do {
    let json = try NSJSONSerialization.JSONObjectWithData(data2, options: []) as! [String: AnyObject]
    if let x = json["names"] as? [String] {
        print(x)
    }
} catch let error as NSError {
    print("Failed to load: \(error.localizedDescription)")
}

////////////////////////////////

func convert(src: NSString) -> NSDictionary {
    // convert String to NSData
    //let src = "{\"names\": \"Bob\", \"city\": \"SP\", \"age\": \"18\"}"
    let data3 = src.dataUsingEncoding(NSUTF8StringEncoding)
    var error: NSError?
    
    // convert NSData to 'AnyObject'
    let anyObj: AnyObject?
    do {
        anyObj = try NSJSONSerialization.JSONObjectWithData(data3!, options: NSJSONReadingOptions(rawValue: 0))
    } catch let error1 as NSError {
        error = error1
        anyObj = nil
    }
    
    if(error != nil) {
        // If there is an error parsing JSON, print it to the console
        print("JSON Error \(error!.localizedDescription)")
        //self.showError()
        return NSDictionary()
    } else {
        
        return anyObj as! NSDictionary
    }
    
}

let seila = convert("{\"names\": \"Bob\", \"city\": \"SP\", \"age\": \"18\"}")


///////////////////////////

let src2 = "[{\"person\": {\"name\": \"Dani\",\"age\": \"24\"}},{\"person\": {\"name\": \"ray\",\"age\": \"70\"}}]"


