//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print("------CRIANDO ARRAY VAZIO----------")

var ArraydeInteiros = [Int]()
print("ArraydeInteiros é do tipo [Int] com \(ArraydeInteiros.count) items.")

ArraydeInteiros.append(3)
print("Esse Array contém \(ArraydeInteiros.count) valor do typo Int")

ArraydeInteiros = []
// Agora é um array vazio mas ainda é do tipo Int

print("------CRIANDO UM ARRAY COM VALOR PADRÃO----------")

var tresValoresDouble = [Double](count: 3, repeatedValue: 5.5)
print("Qtd \(tresValoresDouble.count) items")

var outrosTresValoresDouble = [Double](count: 3, repeatedValue: 2.0)
// anotherThreeDoubles is of type [Double], and equals [2.5, 2.5, 2.5]

var seisValoresDouble = tresValoresDouble + outrosTresValoresDouble
// sixDoubles is inferred as [Double], and equals [0.0, 0.0, 0.0, 2.5, 2.5, 2.5]


print("------CRIANDO UM ARRAY COM STRING----------")

//Criando array string passando o tipo
var listaDeCompras: [String] = ["Ovos", "Leite"]

//Criando array
var outraLista = ["Queijo", "Tomate"]

print("------ACESSANDO E MODIFICANDO UM ARRAY ----------")

//contando o array
print("ArraydeInteiros é do tipo [Int] com \(ArraydeInteiros.count) items.")

//testando se um array está vazio
if listaDeCompras.isEmpty {
    print("A lista está vazia.")
} else {
    print("A lista não está vazia.")
}

//adicionando um item em um array
listaDeCompras.append("Macarrão")

//Adicionalmente podemos utilizar += para incluirmos items em um array
listaDeCompras += ["Manteiga"]
//OU 
listaDeCompras += ["Chocolate", "Vinho", "Arroz"]

//acessando o primeiro item
var item1 = listaDeCompras[0]

//É possível subscrever um ítem 
listaDeCompras[0] = "Uma dúzia de ovos"

//é possível subscrever passando uma sequência de índice
listaDeCompras[4...6] = ["Banana", "Maçã"]

listaDeCompras += ["Café"]

//é possível adicionar um ítem em um índice específico
listaDeCompras.insert("Pão", atIndex: 0)

//remover informando um índice
listaDeCompras.removeAtIndex(0)


listaDeCompras

//remover os últimos 5 itens
let apples = listaDeCompras.removeLast()

//iterando sobre os itens da lista

for item in listaDeCompras {
    print(item)
}

//Se você precisar do índice e do valor use o método enumerate() para cada ítem ele retorna o indice o e valor desse item

for (index, value) in listaDeCompras.enumerate() {
    print("Item \(index + 1): \(value)")
}

















