//
//  main.m
//  Ponteiro_Exemplo
//
//  Created by agesandro scarpioni on 27/08/13.
//  Copyright (c) 2013 Agesandro Scarpioni. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
      /*
        Uma variável é formada por 4 elementos:
                        nome;
                        localização{endereço na memória};
                        tipo{tipo de dado que será armazenado};
                        valor;
        
    Quando alocamos uma variável em um aplicativo, o compilador reserva uma quantidade de memória para armazená-la
    por exemplo se um int precisa de 32 bits para ser armazenado como mostro no primeiro conjunto de slides (ver tabela de tipos de dados), quer dizer que  ele precisa de 4 bytes para armazenar este inteiro, ou seja, cada 8 bits equivale a 1 byte, portanto 32 bits são 4 bytes (8 conjuntos de 4 bits cada=32bits).
       
       Imagine que no iPhone tenha uma grande pilha de bytes um sobre o outro, cada um com um com um endereço, se para armazenar a idade de uma pessoa você gasta 4 bytes, poderíamos estar usando o endereço 500 até o 504 pensando .
       
       veja o exemplo abaixo
       
       
        */
        
        
    
        
        
        
        int idade1= 21;
        int idade2= 21;
        int idade3= 21;
        
        NSLog(@"O conteúdo da variável 1 é %d ", idade1);
        NSLog(@"O conteúdo da variável 2 é %d ", idade2);
        NSLog(@"O conteúdo da variável 3 é %d ", idade3);
        
        int  *enderecoDeMemoria1 = &idade1;  //o símbolo & é um operador de endereço
        int  *enderecoDeMemoria2 = &idade2;
        int  *enderecoDeMemoria3 = &idade3;
        
        NSLog(@"O endereço da variável 1 é %d ", &enderecoDeMemoria1);
        NSLog(@"O endereço da variável 2 é %d ", &enderecoDeMemoria2);
        NSLog(@"O endereço da variável 3 é %d ", &enderecoDeMemoria3);

       
        
        //exemplo abaixo compara conteudo de duas variáveis inteiras
        if (idade1 == idade2) {
            NSLog(@"Ok as variáveis são iguais no conteúdo");
        }else {
            NSLog(@"Ok as variáveis não são iguais no conteúdo");
        }
        
        //exemplo abaixo compara 2 endereços
        if (&idade1 == &idade2) {
            NSLog(@"Os dois endereços não são iguais");
        }else {
            NSLog(@"Os dois endereços são iguais");
        }
        
        //exemplo abaixo compara 2 ponteiros(endereços)
        if (enderecoDeMemoria1 == enderecoDeMemoria2) {
            NSLog(@"Os dois ponteiros possuem o mesmo endereço");
        }else {
            NSLog(@"Os dois ponteiros não possuem o mesmo endereço");
        }
        
        //exemplo abaixo compara o conteúdo dos dois ponteiros
        if (*enderecoDeMemoria1 == *enderecoDeMemoria2) {
            NSLog(@"Os dois conteúdos de ponteiros possuem o mesmo valor");
        }else {
            NSLog(@"Os dois conteúdos de ponteiros não possuem o mesmo valor");
        }
        
        //Dessa forma você consegue observar a diferença entre tipos de referência  e tipos de valor
        // e compreender o que são ponteiros, como todo objeto é referenciado como um ponteiro por isso
        // indicamos o símbolo * na frente do nome de cada objeto, quando utilizamos o objeto
        // passamos a referência, ou seja o ponteiro não o valor.
    
    
        
        
    }
    return 0;
}

