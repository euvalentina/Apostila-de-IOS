//
//  ViewController.swift
//  Aula_Json_Rest
//
//  Created by Usuário Convidado on 15/09/16.
//  Copyright © 2016 Felipe. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var lblRua: UILabel!
    @IBOutlet weak var lblCid: UILabel!
    @IBOutlet weak var lblBai: UILabel!
    @IBOutlet weak var lblEst: UILabel!
    
    
    
    
    @IBAction func btChamar(sender: AnyObject) {
        //cria uma configuração de sessao padrão
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        //cria uma sessao com a configuração default
        session = NSURLSession(configuration: sessionConfig)
        //URL de acesso a API do itunes do top Free App
        
        let cep = "http://viacep.com.br/ws/" + txtCep.text! + "/json"
        
        let url = NSURL(string: cep)
        let task = session!.dataTaskWithURL(url!) { (data:NSData?, response:NSURLResponse?, error:NSError?) in
            //ações que serão executadas quando a execução da task se completa
            //let dado = NSString(data:data!,encoding: NSUTF8StringEncoding)
            //print(dado)
            
            let rua = self.retornarDado(data!, campo: "logradouro")
            let cid = self.retornarDado(data!, campo: "localidade")
            let bai = self.retornarDado(data!, campo: "bairro")
            let est = self.retornarDado(data!, campo: "uf")
            
                dispatch_async(dispatch_get_main_queue(), {
                    self.lblRua.text = rua
                    self.lblCid.text = cid
                    self.lblBai.text = bai
                    self.lblEst.text = est
                })
           
            
            
        }
        
        
        task.resume()
        
        
    }
    
    
    @IBOutlet weak var txtCep: UITextField!
    
    
    
    var session: NSURLSession?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    
    
    
    func retornarDado(data: NSData, campo:String) -> String? {
        var resposta:String?=nil
        do{
            //faz a leitura dos valores do Json, NSJSONSerialization faz o Parser do Json
            let json = try NSJSONSerialization.JSONObjectWithData(data, options: []) as! [String:AnyObject]
            //cria um dicionário a partir da chave feed
            if let feed = json[campo] as? String{
                return feed
            }
            
        }catch let error as NSError{
            resposta = "Falha ao carregar: \(error.description)"
        }
        return resposta
    }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    
    
}

