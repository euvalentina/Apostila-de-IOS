//
//  Carros.swift
//  JsonTabelaFipe
//
//  Created by Usuário Convidado on 26/10/16.
//  Copyright © 2016 AGESANDRO SCARPIONI. All rights reserved.
//

import UIKit

class Carro: NSObject {
    var marca:String = ""
    var id:Int = 0

}
