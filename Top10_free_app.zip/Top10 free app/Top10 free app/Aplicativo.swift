//
//  Aplicativo.swift
//  Top10 free app
//
//  Created by Usuário Convidado on 26/10/16.
//  Copyright © 2016 AGESANDRO SCARPIONI. All rights reserved.
//

import UIKit

class Aplicativo: NSObject {
    var nomeApp:String = ""
    

}
