//
//  ViewController.swift
//  Exemplo1_TableView1_Swift
//
//  Created by Usuário Convidado on 21/09/16.
//  Copyright © 2016 Agesandro Scarpioni. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var minhaTabela: UITableView!
    
    var animal = ["Urso", "Elefante", "Girafa", "Rinoceronte"]
    var foto = ["urso.png", "ele.png", "girafa.png", "rino.png"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //vou informar quem será o delegate
        //dos protocolos via interface e
        //não por código como foi feito abaixo
        
        //minhaTabela.dataSource = self
        //minhaTabela.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animal.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let celula = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as UITableViewCell
        
        celula.textLabel?.text = animal[indexPath.row]
        celula.imageView?.image = UIImage(named: foto[indexPath.row])
        celula.detailTextLabel?.text = "Africa"
        celula.accessoryType = .DisclosureIndicator
        return celula
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("Selecionamos o animal \(animal[indexPath.row])")
    }


}














