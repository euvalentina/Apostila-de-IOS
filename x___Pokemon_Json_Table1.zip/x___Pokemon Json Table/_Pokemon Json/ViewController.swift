//
//  ViewController.swift
//  _Pokemon Json
//
//  Created by Agesandro Scarpioni on 19/09/16.
//  Copyright © 2016 Agesandro Scarpioni. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

