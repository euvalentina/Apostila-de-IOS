//
//  Endereco.swift
//  Aula_Json_Rest
//
//  Created by Usuário Convidado on 15/09/16.
//  Copyright © 2016 Felipe. All rights reserved.
//

import Cocoa

class Endereco: NSObject {
    
    
    NSString *nome;
    
    
    
    
    

}
