//
//  ViewController.swift
//  Aula_Json_Rest
//
//  Created by Usuário Convidado on 15/09/16.
//  Copyright © 2016 Felipe. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var lblRua: UILabel!
    
    @IBAction func btChamar(sender: AnyObject) {
        
        nomeRua()
        
    }

    
    @IBOutlet weak var txtCep: UITextField!
    
    
    
    var session: NSURLSession?
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    
    func nomeRua() {
        
          //cria uma configuração de sessao padrão
        let sessionConfig = NSURLSessionConfiguration.defaultSessionConfiguration()
        //cria uma sessao com a configuração default
        session = NSURLSession(configuration: sessionConfig)
        //URL de acesso a API do itunes do top Free App
        
        let cep = "http://viacep.com.br/ws/" + (txtCep?.text)! + "/json"
        
        let url = NSURL(string: cep)
        let task = session!.dataTaskWithURL(url!) { (data:NSData?, response:NSURLResponse?, error:NSError?) in
            //ações que serão executadas quando a execução da task se completa
            //let dado = NSString(data:data!,encoding: NSUTF8StringEncoding)
            //print(dado)
            
            if let rua = self.retornarRua(data!){
                dispatch_async(dispatch_get_main_queue(), {
                    self.lblRua.text = rua
                })
            }
            
            
        }
        
        
        task.resume()
      
        
    }
    
    
    
    
    func retornarRua(data: NSData) -> String? {
        var resposta:String?=nil
        do{
            //faz a leitura dos valores do Json, NSJSONSerialization faz o Parser do Json
            let json = try NSJSONSerialization.JSONObjectWithData(data, options: []) as! [String:AnyObject]
            //cria um dicionário a partir da chave feed
            if let feed = json["logradouro"] as? String{
                return feed
            }
            
        }catch let error as NSError{
            resposta = "Falha ao carregar: \(error.description)"
        }
        return resposta
    }
    

    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }


}

