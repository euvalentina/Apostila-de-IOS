//
//  Endereco.swift
//  Aula_Json_Rest
//
//  Created by Usuário Convidado on 22/09/16.
//  Copyright © 2016 Felipe. All rights reserved.
//

import UIKit

class Endereco: NSObject {
    var rua:String = ""
    var bairro:String = ""
    var cidade:String = ""
    var uf:String = ""

}
