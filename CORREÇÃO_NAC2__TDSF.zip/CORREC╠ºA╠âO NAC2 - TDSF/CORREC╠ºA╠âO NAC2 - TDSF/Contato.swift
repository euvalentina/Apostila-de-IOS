//
//  Contato.swift
//  CORREÇÃO NAC2 - TDSF
//
//  Created by Usuário Convidado on 26/10/16.
//  Copyright © 2016 AGESANDRO SCARPIONI. All rights reserved.
//

import UIKit

class Contato: NSObject {
    
    var nome:[String] = []
    var telefone:[String] = []

}
